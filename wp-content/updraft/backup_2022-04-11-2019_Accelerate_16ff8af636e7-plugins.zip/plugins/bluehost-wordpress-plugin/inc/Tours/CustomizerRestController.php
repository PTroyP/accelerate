<?php

namespace Newfold\Plugin\Tours;

class CustomizerRestEndpoint {
    
}
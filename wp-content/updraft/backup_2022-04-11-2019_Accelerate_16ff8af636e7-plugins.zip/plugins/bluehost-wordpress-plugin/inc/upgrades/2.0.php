<?php

// Delete old transients
delete_transient( 'mm_api_calls' );

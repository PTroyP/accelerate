<p>
	<?php printf( __( 'Use this integration by adding the "Mailchimp" field to <a href="%s">your WPForms forms</a>.', 'mailchimp-for-wp' ), admin_url( 'admin.php?page=wpforms-overview' ) ); ?>
</p>
